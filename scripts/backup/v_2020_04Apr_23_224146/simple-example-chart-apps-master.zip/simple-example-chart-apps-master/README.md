# simple-example-chart-apps

Some very simple apps hosted at https://dash-simple-apps.plotly.host/ meant for embedding into https://plot.ly/python
